import pygame
import random
import sys
from pygame import mixer
import time

# Initialize
pygame.init()
WIDTH, HEIGHT = 1500, 1000
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DINO GAME")
pygame.display.set_icon(pygame.image.load("tyrannosaurus-rex.png"))
clock = pygame.time.Clock()

# Load assets
ground_img = pygame.transform.scale(pygame.image.load("dinoland.png"), (WIDTH, 40))
dino_run_images = [pygame.image.load(f"Run ({i}).png") for i in range(1, 9)]
dino_jump_image = [pygame.image.load(f"Jump ({i}).png") for i in range(1, 12)]
trap_img = pygame.transform.scale(pygame.image.load("trap.png"), (60, 60))
coin_img = pygame.transform.scale(pygame.image.load("game-coin.png"), (60, 60))
fireball_img = pygame.transform.scale(pygame.image.load("fire ball.png"), (100, 100))
monster_walk_images = [pygame.image.load(f"character_zombie_walk{i}.png") for i in range(7)]
coin1_img = pygame.transform.scale(pygame.image.load("coin.png"),(60,60))
interface_bg = pygame.transform.scale(pygame.image.load("ChatGPT Image May 28, 2025, 04_39_28 PM.png"), (WIDTH, HEIGHT))


background = pygame.transform.scale(pygame.image.load("ChatGPT Image May 28, 2025, 04_39_28 PM.png"), (WIDTH, HEIGHT))
player_pose = pygame.image.load("Idle (1).png")
font = pygame.font.SysFont("Impact", 40)


coin_sound = pygame.mixer.Sound("retro-coin-4-236671.mp3")
fire_sound = pygame.mixer.Sound("explosion.mp3")
ground_img2 =  pygame.transform.scale(pygame.image.load("ground 2.png"), (1500, 800))
thunder_sound = pygame.mixer.Sound("mixkit-explosion-hit-1704.wav")
lightning_bolt_img = pygame.image.load("lightning1-removebg-preview.png").convert_alpha()
lightning_bolt_img = pygame.transform.scale(lightning_bolt_img, (WIDTH, HEIGHT))
coin1_sound = pygame.mixer.Sound("coin-collision-sound-342335.mp3")

lightning_timer = 0
lightning_duration = 300  # ms
lightning_pos_x = 0


# Variables
ground_x = 0
dino_x, dino_y = 100, 400
dino_index, frame_count = 0, 0
is_jumping = False
jump_velocity, gravity = -15, 0.4

obstacles = [{'img': trap_img, 'x': random.randint(1600, 1700), 'y': 780} for _ in range(2)]
coins = [{'img': coin_img, 'x': random.randint(1600, 3000), 'y': random.choice([750, 1000])} for _ in range(5)]

fireballs = []

monsters = [{
    'x': random.randint(3000, 4000),
    'y': 450,
    'index': 0,
    'frame_count': 0
} for _ in range(2)]

coin_score = 0
font = pygame.font.SysFont(None, 50)

level = 1
coins_for_next_level = 10
game_speed = 7

coin1 = {
    'img': coin1_img,
    'x': random.randint(3000, 4000),
    'y': 750,
    'visible': False
}

start_btn_img = pygame.image.load("button_rectangle_depth_border.png")
start_btn_rect = start_btn_img.get_rect(center=(WIDTH//2, HEIGHT//2 - 50))

# Function to draw Dino
def draw_dino(run_index, is_jumping):
    img = dino_jump_image[0] if is_jumping else dino_run_images[run_index]
    screen.blit(img, (dino_x, dino_y))
    return img


def show_interface_screen():
    screen.blit(interface_bg, (0, 0))

    # Add title or instructions
    font = pygame.font.SysFont(None, 80)
    title = font.render("Dino Adventure", True, (255, 255, 255))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 150))

    sub_font = pygame.font.SysFont(None, 50)
    play_text = sub_font.render("Press SPACE to Start", True, (255, 255, 255))
    screen.blit(play_text, (WIDTH // 2 - play_text.get_width() // 2, 300))

    pygame.display.update()
show_interface_screen()
waiting = True
while waiting:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            waiting = False


# Level logic
if coin_score >= 20:
    current_level = 3
elif coin_score >= 10:
    current_level = 2
else:
    current_level = 1

# Main loop
running = True
while running:
    dt = clock.tick(90)
    screen.fill((135, 206, 250))

    # Move ground
    ground_x -= game_speed
    if ground_x <= -WIDTH:
        ground_x = 0
    screen.blit(ground_img, (ground_x, 800))
    screen.blit(ground_img, (ground_x + WIDTH, 800))

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not is_jumping:
                is_jumping = True
                jump_velocity = -15
            elif event.key == pygame.K_f:
                fireballs.append({'x': dino_x + 60, 'y': dino_y + 200})
                fire_sound.play()
    if event.type == pygame.WINDOWTAKEFOCUS:
        if start_btn_rect.collidepoint(event.pos):
            print("Start Game!")

    if level == 3 :
        screen.fill((20, 20, 40))  # scary dark sky
    if level == 5 :
        screen.fill((90,70,100))
        # Randomly start lightning flash
        if lightning_timer <= 0 and random.randint(0, 300) == 1:
            lightning_timer = lightning_duration
            lightning_pos_x = random.randint(100, WIDTH - 400)
            thunder_sound.play()
            print("Lightning & thunder triggered")

            # If lightning is active
        if lightning_timer > 0:
            # Flash flicker
            if (lightning_timer // 50) % 2 == 0:
                flash_surface = pygame.Surface((WIDTH, HEIGHT))
                flash_surface.set_alpha(180)
                flash_surface.fill((255, 255, 255))
                screen.blit(flash_surface, (0, 0))
                screen.blit(lightning_bolt_img, (lightning_pos_x, 0))

            lightning_timer -= dt

        # Decrease timer
        lightning_timer -= clock.get_time()

    if lightning_timer > 0:
        if (lightning_timer // 50) % 2 == 0:  # flicker effect
            lightning_flash = pygame.Surface((WIDTH, HEIGHT))
            lightning_flash.set_alpha(180)
            lightning_flash.fill((255, 255, 255))
            screen.blit(lightning_flash, (0, 0))
            screen.blit(lightning_bolt_img, (lightning_pos_x, 100))
        lightning_timer -= clock.get_time()

    # Dino jump
    if is_jumping:
        dino_y += jump_velocity
        jump_velocity += gravity
        if dino_y >= 400:
            dino_y = 400
            is_jumping = False

    # Animation
    frame_count += 1
    if frame_count >= 5:
        dino_index = (dino_index + 1) % len(dino_run_images)
        frame_count = 0

    # Dino rect/mask
    dino_img = dino_jump_image[0] if is_jumping else dino_run_images[dino_index]
    dino_rect = pygame.Rect(dino_x, dino_y, dino_img.get_width(), dino_img.get_height())
    dino_mask = pygame.mask.from_surface(dino_img)

    # Obstacles
    for trap in obstacles:
        trap['x'] -= game_speed
        if trap['x'] < -90:
            trap['x'] = random.randint(WIDTH + 100, WIDTH + 300)


        screen.blit(trap['img'], (trap['x'], trap['y']))

        trap_mask = pygame.mask.from_surface(trap['img'])
        offset = (trap['x'] - dino_x, trap['y'] - dino_y)
        if dino_mask.overlap(trap_mask, offset):
            print("\U0001F4A5 Dino pixel-touched the trap! Game Over.")
            running = False

    # Coins
    for coin in coins:
        coin['x'] -= game_speed
        screen.blit(coin['img'], (coin['x'], coin['y']))
        coin_mask = pygame.mask.from_surface(coin['img'])
        offset = (coin['x'] - dino_x, coin['y'] - dino_y)

        if dino_mask.overlap(coin_mask, offset):
            coin_score += 1
            coin_sound.play()
            coin['x'] = random.randint(1600, 3000)
            coin['y'] = 750

            if coin_score >= level * coins_for_next_level:
                level += 1
                game_speed += 2
                print(f"\U0001F525 Level Up! You're now on Level {level}")

        # Reposition coin if it moves off-screen
        if coin['x'] < -60:
            coin['x'] = random.randint(1600, 3000)
            coin['y'] = 750

    # Fireballs
    for fb in fireballs[:]:
        fb['x'] += 12
        screen.blit(fireball_img, (fb['x'], fb['y']))
        if fb['x'] > WIDTH:
            fireballs.remove(fb)
            continue
        fireball_rect = pygame.Rect(fb['x'], fb['y'], fireball_img.get_width(), fireball_img.get_height())
        fireball_mask = pygame.mask.from_surface(fireball_img)

        for trap in obstacles[:]:
            trap_rect = pygame.Rect(trap['x'], trap['y'], trap['img'].get_width(), trap['img'].get_height())
            trap_mask = pygame.mask.from_surface(trap['img'])
            offset = (trap['x'] - fb['x'], trap['y'] - fb['y'])
            if fireball_mask.overlap(trap_mask, (trap['x'] - fb['x'], trap['y'] - fb['y'])):
                fire_sound.play()
                obstacles.remove(trap)
                fireballs.remove(fb)
                obstacles.append({'img': trap_img, 'x': random.randint(WIDTH + 300, WIDTH + 1000), 'y': 780})
                break

        if level >= 4 :
            enemy_fireballs = []
            enemy_fireball_cooldown = 2000  # milliseconds between enemy fireballs
            enemy_fireball_timer = 0
            enemy_fireball_timer -= dt
            if enemy_fireball_timer <= 0:
                # Spawn enemy fireball at right side, random y near ground or monsters height
                enemy_fireballs.append({'x': WIDTH, 'y': random.randint(400, 500)})
                enemy_fireball_timer = enemy_fireball_cooldown
            for efb in enemy_fireballs[:]:
                efb['x'] -= 10  # move left towards dino
                screen.blit(fireball_img, (efb['x'], efb['y']))

                # Create rect and mask for collision
                efb_rect = pygame.Rect(efb['x'], efb['y'], fireball_img.get_width(), fireball_img.get_height())
                efb_mask = pygame.mask.from_surface(fireball_img)

                # Dino rect and mask (reuse dino_rect and dino_mask)
                offset = (int(efb['x'] - dino_x), int(efb['y'] - dino_y))
                if dino_mask.overlap(efb_mask, offset):
                    print("🔥 Dino hit by enemy fireball! Game Over.")
                    pygame.time.delay(1000)
                    running = False

                # Remove fireball beyond screen
                if efb['x'] < -100:
                    enemy_fireballs.remove(efb)

        for monster in monsters[:]:
            monster_img = monster_walk_images[monster['index']]
            monster_mask = pygame.mask.from_surface(monster_img)
            offset = (monster['x'] - fb['x'], monster['y'] - fb['y'])
            if fireball_mask.overlap(monster_mask, offset):
                fire_sound.play()
                monsters.remove(monster)
                fireballs.remove(fb)
                monsters.append({
                    'x': random.randint(1700, 1900),
                    'y': 450,
                    'index': 0,
                    'frame_count': 0
                })
                break

    # Monsters
    for monster in monsters :
        monster['frame_count'] += 1
        if monster['frame_count'] >= 5:
            monster['index'] = (monster['index'] + 1) % len(monster_walk_images)
            monster['frame_count'] = 0
        monster_img = monster_walk_images[monster['index']]
        monster['x'] -= game_speed - 2
        screen.blit(monster_img, (monster['x'], monster['y']))

        monster_mask = pygame.mask.from_surface(monster_img)
        offset = (monster['x'] - dino_x, monster['y'] - dino_y)
        if dino_mask.overlap(monster_mask, offset):
            print("\U0001F480 Animated Monster hit Dino! Game Over.")
            pygame.time.delay(1000)
            running = False


        if monster['x'] < -100:
            monster['x'] = random.randint(1900, 3000)
    if level == 1:
        background_img = pygame.image.load("dinoland.png")
    elif level == 2:
        background_img = pygame.image.load("dinoland.png")
    elif level == 3:
        background_img = pygame.image.load("ground 2.png")

    # Special coin logic (spawn once every 5th level only)
    if level % 5  == 0 and not coin1['visible']:
        coin1['visible'] = True
        coin1['x'] = random.randint(4000, 5000)

    # Handle special coin drawing and collection
    if coin1['visible']:
        coin1['x'] -= game_speed
        screen.blit(coin1['img'], (coin1['x'], coin1['y']))
        coin1_mask = pygame.mask.from_surface(coin1['img'])
        offset = (int(coin1['x']) - dino_x, int(coin1['y']) - dino_y)

        if dino_mask.overlap(coin1_mask, offset):
            coin1_sound.play()
            coin_score += 5  # Bonus!
            level += 1  # Level up on collect
            print(f"🎯 SPECIAL COIN COLLECTED! LEVEL UP TO {level}")
            coin1['visible'] = False

        if coin1['x'] < -60:
            coin1['visible'] = False



    # Keep this AFTER background blit:
    screen.blit(ground_img, (ground_x, 800))
    screen.blit(ground_img, (ground_x + WIDTH, 800))

    # Draw dino
    draw_dino(dino_index, is_jumping)

    # UI
    coin_text = font.render(f"Coins: {coin_score}", True, (255, 255, 255))
    screen.blit(coin_text, (100, 100))
    screen.blit(coin_img, (50, 90))
    level_text = font.render(f"Level: {level}", True, (255, 255, 255))
    screen.blit(level_text, (WIDTH - 200, 100))

    pygame.display.flip()

pygame.quit()
sys.exit()

if __name__ == "__main__":
    main_menu()
